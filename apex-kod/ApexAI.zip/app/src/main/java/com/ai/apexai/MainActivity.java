package com.ai.apexai;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import com.ai.apexai.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private MainBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		// APEX PROJECT - PREMIUM GOOGLE M3 PRO SÜRÜMÜ (DERLEME HATASI DÜZELTİLDİ)
		final float den = MainActivity.this.getResources().getDisplayMetrics().density;
		final int dp280 = (int)(280 * den);
		final int dp65 = (int)(65 * den);
		final int dp50 = (int)(50 * den);
		final int dp28 = (int)(28 * den);
		final int dp24 = (int)(24 * den); 
		final int dp20 = (int)(20 * den);
		final int dp18 = (int)(18 * den); // HATA VEREN DEĞİŞKEN BAŞARIYLA EKLENDİ 🚀
		final int dp16 = (int)(16 * den);
		final int dp12 = (int)(12 * den);
		final int dp10 = (int)(10 * den);
		final int dp8 = (int)(8 * den);
		final int dp6 = (int)(6 * den);
		final int dp4 = (int)(4 * den);
		final int dp3 = (int)(3 * den); 
		final int dp2 = (int)(2 * den);
		final int dp1 = (int)(1 * den);
		
		final android.content.SharedPreferences sp = MainActivity.this.getSharedPreferences("ApexChats", android.content.Context.MODE_PRIVATE);
		final String[] currentChatId = {""}; 
		final String[] selectedModel = {"Genius"};
		final String[] thinkingTime = {"Standart"}; 
		final boolean[] isPrivateMode = {false};
		
		// GİZLİ SOHBET GEÇİCİ BELLEK HAVUZU
		final org.json.JSONArray[] privateHistory = {new org.json.JSONArray()};
		
		// --- AKILLI KONU BAŞLIĞI OLUŞTURUCU ---
		class TitleGenerator {
			public String generate(String msg) {
				try {
					String clean = msg.trim().replaceAll("[\\p{Punct}&&[^<>]]", "");
					String[] words = clean.split("\\s+");
					StringBuilder sb = new StringBuilder();
					int limit = Math.min(words.length, 3);
					for (int i = 0; i < limit; i++) {
						if (words[i].length() > 0) {
							sb.append(Character.toUpperCase(words[i].charAt(0))).append(words[i].substring(1)).append(" ");
						}
					}
					String title = sb.toString().trim();
					if (title.isEmpty()) return "Yeni Sohbet";
					return title.length() > 20 ? title.substring(0, 18) + "..." : title;
				} catch(Exception e) {
					return "Yeni Sohbet";
				}
			}
		}
		final TitleGenerator smartTitleGen = new TitleGenerator();
		
		// --- PREMIUM SOHBET AKIŞ MOTORU (AI CANVAS DÜZENİ) ---
		class DynamicBubbleBuilder {
			public void build(final android.widget.LinearLayout container, final boolean isUser, final String text, final int padding, final int radius, final android.widget.EditText inputField) {
				final android.widget.LinearLayout bubble = new android.widget.LinearLayout(MainActivity.this);
				bubble.setOrientation(android.widget.LinearLayout.VERTICAL);
				
				android.widget.LinearLayout.LayoutParams bParams = new android.widget.LinearLayout.LayoutParams(-2, -2);
				android.graphics.drawable.GradientDrawable bubbleBg = new android.graphics.drawable.GradientDrawable();
				
				if (isUser) {
					bParams.gravity = android.view.Gravity.END;
					bParams.setMargins(dp50, dp8, 0, dp8); 
					bubble.setPadding(dp16, dp12, dp16, dp12);
					
					if (isPrivateMode[0]) {
						bubbleBg.setColor(0xFF3C4043); 
						bubbleBg.setStroke(dp1, 0xFF5F6368);
					} else {
						bubbleBg.setColor(0xFF2A2B2D); 
						bubbleBg.setStroke(dp1, 0xFF3C4043);
					}
					bubbleBg.setCornerRadius(dp18);
					bubble.setBackground(bubbleBg);
					
					bubble.setOnLongClickListener(new android.view.View.OnLongClickListener() {
						@Override
						public boolean onLongClick(android.view.View v) {
							android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
							builder.setTitle("İşlemler");
							String[] items = {"Metni Kopyala", "Düzenlemek İçin Al"};
							builder.setItems(items, new android.content.DialogInterface.OnClickListener() {
								@Override
								public void onClick(android.content.DialogInterface dialog, int which) {
									if (which == 0) {
										android.content.ClipboardManager clipboard = (android.content.ClipboardManager) MainActivity.this.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
										android.content.ClipData clip = android.content.ClipData.newPlainText("ApexText", text);
										clipboard.setPrimaryClip(clip);
										android.widget.Toast.makeText(MainActivity.this, "Kopyalandı!", android.widget.Toast.LENGTH_SHORT).show();
									} else if (which == 1) {
										inputField.setText(text);
										inputField.setSelection(text.length());
										inputField.requestFocus();
									}
								}
							});
							android.app.AlertDialog alert = builder.create();
							alert.show();
							if(alert.getWindow() != null) alert.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF1E1E1F));
							return true;
						}
					});
					
				} else {
					bParams.gravity = android.view.Gravity.START;
					bParams.setMargins(0, dp12, dp50, dp12); 
					bubble.setPadding(0, dp4, 0, dp4);
					if(text.startsWith("⚠️")) {
						bubbleBg.setColor(0x22FF1744);
						bubbleBg.setStroke(dp1, 0xFFFF1744);
						bubbleBg.setCornerRadius(dp12);
						bubble.setBackground(bubbleBg);
						bubble.setPadding(dp12, dp12, dp12, dp12);
					}
				}
				bubble.setLayoutParams(bParams);
				
				android.widget.TextView tvSender = new android.widget.TextView(MainActivity.this);
				tvSender.setText(isUser ? "Siz" : "Apex"); 
				tvSender.setTextColor(isUser ? 0xFF8E918F : 0xFFA8C7FA);
				tvSender.setTextSize(11);
				tvSender.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
				tvSender.setPadding(0, 0, 0, dp4);
				bubble.addView(tvSender);
				
				android.widget.TextView tvText = new android.widget.TextView(MainActivity.this);
				tvText.setText(text);
				tvText.setTextColor(0xFFE3E3E3);
				tvText.setTextSize(15f);
				tvText.setLineSpacing(5f, 1f);
				
				if (!isUser) {
					tvText.setTextIsSelectable(true);
				}
				
				bubble.addView(tvText);
				
				bubble.setAlpha(0f);
				bubble.setScaleX(0.97f);
				container.addView(bubble);
				
				bubble.animate()
				.alpha(1f)
				.scaleX(1f)
				.setDuration(280)
				.setInterpolator(new android.view.animation.PathInterpolator(0.1f, 1f, 0.1f, 1f))
				.start();
			}
		}
		final DynamicBubbleBuilder buildDynamicBubble = new DynamicBubbleBuilder();
		
		// 1. ANA KÖK KATMAN
		final android.widget.RelativeLayout rootLayout = new android.widget.RelativeLayout(MainActivity.this);
		rootLayout.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(-1, -1));
		
		// 2. MERKEZİ İÇERİK PANELİ
		final android.widget.RelativeLayout mainContent = new android.widget.RelativeLayout(MainActivity.this);
		mainContent.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(-1, -1));
		mainContent.setBackgroundColor(0xFF131314); 
		
		android.animation.LayoutTransition heavyTransition = new android.animation.LayoutTransition();
		heavyTransition.setDuration(android.animation.LayoutTransition.APPEARING, 200);
		heavyTransition.setDuration(android.animation.LayoutTransition.DISAPPEARING, 100);
		mainContent.setLayoutTransition(heavyTransition);
		
		// --- ÜST HEADER BAR ---
		final android.widget.LinearLayout header = new android.widget.LinearLayout(MainActivity.this);
		header.setId(2001);
		android.widget.RelativeLayout.LayoutParams headerParams = new android.widget.RelativeLayout.LayoutParams(-1, -2);
		headerParams.addRule(android.widget.RelativeLayout.ALIGN_PARENT_TOP);
		header.setLayoutParams(headerParams);
		header.setOrientation(android.widget.LinearLayout.VERTICAL);
		header.setBackgroundColor(0xFF131314);
		
		android.widget.LinearLayout headerRow1 = new android.widget.LinearLayout(MainActivity.this);
		headerRow1.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		headerRow1.setGravity(android.view.Gravity.CENTER_VERTICAL);
		headerRow1.setPadding(dp16, dp16, dp16, dp8);
		
		android.widget.TextView btnMenu = new android.widget.TextView(MainActivity.this);
		btnMenu.setText("☰");
		btnMenu.setTextColor(0xFFA8C7FA);
		btnMenu.setTextSize(22);
		btnMenu.setPadding(0, 0, dp16, 0);
		headerRow1.addView(btnMenu);
		
		final android.widget.TextView txtTitle = new android.widget.TextView(MainActivity.this);
		txtTitle.setText("Apex"); 
		txtTitle.setTextColor(0xFFE3E3E3);
		txtTitle.setTextSize(19);
		txtTitle.setTypeface(android.graphics.Typeface.create("sans-serif-google", android.graphics.Typeface.NORMAL));
		headerRow1.addView(txtTitle);
		
		android.view.View spacer = new android.view.View(MainActivity.this);
		android.widget.LinearLayout.LayoutParams spacerParams = new android.widget.LinearLayout.LayoutParams(0, 1);
		spacerParams.weight = 1;
		spacer.setLayoutParams(spacerParams);
		headerRow1.addView(spacer);
		
		// MODEL SEÇİCİ SLIDER CHIPS
		android.widget.LinearLayout toggleContainer = new android.widget.LinearLayout(MainActivity.this);
		toggleContainer.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		android.graphics.drawable.GradientDrawable toggleBg = new android.graphics.drawable.GradientDrawable();
		toggleBg.setColor(0xFF1E1E1F);
		toggleBg.setCornerRadius(dp24);
		toggleBg.setStroke(dp1, 0xFF282A2C);
		toggleContainer.setBackground(toggleBg);
		toggleContainer.setPadding(dp4, dp4, dp4, dp4);
		
		final android.widget.TextView tvGenius = new android.widget.TextView(MainActivity.this);
		tvGenius.setText("Genius");
		tvGenius.setTextSize(11);
		tvGenius.setPadding(dp12, dp6, dp12, dp6);
		tvGenius.setTextColor(0xFF042B56);
		android.graphics.drawable.GradientDrawable activeRb = new android.graphics.drawable.GradientDrawable();
		activeRb.setColor(0xFFC2E7FF); activeRb.setCornerRadius(dp20);
		tvGenius.setBackground(activeRb);
		
		final android.widget.TextView tvMacro = new android.widget.TextView(MainActivity.this);
		tvMacro.setText("Macro");
		tvMacro.setTextSize(11);
		tvMacro.setPadding(dp12, dp6, dp12, dp6);
		tvMacro.setTextColor(0xFFC4C7C5);
		
		final android.widget.TextView tvMacroFlash = new android.widget.TextView(MainActivity.this);
		tvMacroFlash.setText("Flash");
		tvMacroFlash.setTextSize(11);
		tvMacroFlash.setPadding(dp12, dp6, dp12, dp6);
		tvMacroFlash.setTextColor(0xFFC4C7C5);
		
		toggleContainer.addView(tvGenius);
		toggleContainer.addView(tvMacro);
		toggleContainer.addView(tvMacroFlash);
		headerRow1.addView(toggleContainer);
		header.addView(headerRow1);
		
		android.widget.LinearLayout headerRow2 = new android.widget.LinearLayout(MainActivity.this);
		headerRow2.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		headerRow2.setGravity(android.view.Gravity.END | android.view.Gravity.CENTER_VERTICAL);
		headerRow2.setPadding(dp16, 0, dp16, dp10);
		
		android.widget.TextView tvThinkLabel = new android.widget.TextView(MainActivity.this);
		tvThinkLabel.setText("Düşünme: ");
		tvThinkLabel.setTextColor(0xFF8E918F);
		tvThinkLabel.setTextSize(11);
		headerRow2.addView(tvThinkLabel);
		
		android.widget.LinearLayout thinkToggleContainer = new android.widget.LinearLayout(MainActivity.this);
		thinkToggleContainer.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		android.graphics.drawable.GradientDrawable thinkToggleBg = new android.graphics.drawable.GradientDrawable();
		thinkToggleBg.setColor(0xFF1E1E1F);
		thinkToggleBg.setCornerRadius(dp20);
		thinkToggleContainer.setBackground(thinkToggleBg);
		thinkToggleContainer.setPadding(dp2, dp2, dp2, dp2);
		
		final android.widget.TextView tvThinkStandart = new android.widget.TextView(MainActivity.this);
		tvThinkStandart.setText("Normal");
		tvThinkStandart.setTextSize(10);
		tvThinkStandart.setPadding(dp8, dp4, dp8, dp4);
		tvThinkStandart.setTextColor(0xFF042B56);
		android.graphics.drawable.GradientDrawable activeThinkBg = new android.graphics.drawable.GradientDrawable();
		activeThinkBg.setColor(0xFFC2E7FF); activeThinkBg.setCornerRadius(dp16);
		tvThinkStandart.setBackground(activeThinkBg);
		
		final android.widget.TextView tvThinkExtended = new android.widget.TextView(MainActivity.this);
		tvThinkExtended.setText("Derin");
		tvThinkExtended.setTextSize(10);
		tvThinkExtended.setPadding(dp8, dp4, dp8, dp4);
		tvThinkExtended.setTextColor(0xFFC4C7C5);
		
		thinkToggleContainer.addView(tvThinkStandart);
		thinkToggleContainer.addView(tvThinkExtended);
		headerRow2.addView(thinkToggleContainer);
		header.addView(headerRow2);
		
		android.view.View topDivider = new android.view.View(MainActivity.this);
		topDivider.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, dp1));
		topDivider.setBackgroundColor(0xFF212224);
		header.addView(topDivider);
		
		mainContent.addView(header);
		
		// --- ALT MESAJ GİRİŞ ALANI (APEX ÖZEL KAPSÜLÜ) ---
		android.widget.LinearLayout inputBar = new android.widget.LinearLayout(MainActivity.this);
		inputBar.setId(2002);
		android.widget.RelativeLayout.LayoutParams inputParams = new android.widget.RelativeLayout.LayoutParams(-1, -2);
		inputParams.addRule(android.widget.RelativeLayout.ALIGN_PARENT_BOTTOM);
		inputBar.setLayoutParams(inputParams);
		inputBar.setBackgroundColor(0xFF131314);
		inputBar.setOrientation(android.widget.LinearLayout.VERTICAL);
		inputBar.setPadding(dp16, dp8, dp16, dp16);
		
		final android.widget.LinearLayout inputSubContainer = new android.widget.LinearLayout(MainActivity.this);
		inputSubContainer.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		android.graphics.drawable.GradientDrawable inputPanelBg = new android.graphics.drawable.GradientDrawable();
		inputPanelBg.setColor(0xFF1E1E1F);
		inputPanelBg.setCornerRadius(dp28); 
		inputPanelBg.setStroke(dp1, 0xFF303134); 
		inputSubContainer.setBackground(inputPanelBg);
		inputSubContainer.setPadding(dp16, dp4, dp8, dp4);
		inputSubContainer.setGravity(android.view.Gravity.CENTER_VERTICAL);
		
		final android.widget.EditText messageInput = new android.widget.EditText(MainActivity.this);
		android.widget.LinearLayout.LayoutParams editParams = new android.widget.LinearLayout.LayoutParams(0, -2);
		editParams.weight = 1;
		messageInput.setLayoutParams(editParams);
		messageInput.setBackgroundColor(android.graphics.Color.TRANSPARENT);
		messageInput.setHint("Apex'e sorun..."); // GEMINI BELGE VE İBARELERİ TAMAMEN SİLİNDİ
		messageInput.setHintTextColor(0xFF8E918F);
		messageInput.setTextColor(0xFFFFFFFF);
		messageInput.setTextSize(15f);
		messageInput.setMaxLines(4);
		messageInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
		inputSubContainer.addView(messageInput);
		
		// MİKROFON BUTONU ALTYAPISI
		final android.widget.TextView btnVoice = new android.widget.TextView(MainActivity.this);
		btnVoice.setText("🎤");
		btnVoice.setTextColor(0xFFA8C7FA);
		btnVoice.setTextSize(20);
		btnVoice.setPadding(dp8, 0, dp12, 0);
		inputSubContainer.addView(btnVoice);
		
		final android.speech.SpeechRecognizer speechRecognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
		final android.content.Intent speechIntent = new android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
		speechIntent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
		speechIntent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
		speechIntent.putExtra(android.speech.RecognizerIntent.EXTRA_CALLING_PACKAGE, MainActivity.this.getPackageName());
		
		final boolean[] isListening = {false};
		final Runnable resetVoiceUI = new Runnable() {
			@Override public void run() {
				btnVoice.setText("🎤");
				btnVoice.setTextColor(isPrivateMode[0] ? 0xFF9AA0A6 : 0xFFA8C7FA);
				messageInput.setHint(isPrivateMode[0] ? "Gizli modda Apex'e sorun..." : "Apex'e sorun...");
				isListening[0] = false;
			}
		};
		
		speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener() {
			@Override public void onReadyForSpeech(android.os.Bundle params) { messageInput.setHint("Dinleniyor..."); }
			@Override public void onBeginningOfSpeech() {}
			@Override public void onRmsChanged(float rmsdB) {}
			@Override public void onBufferReceived(byte[] buffer) {}
			@Override public void onEndOfSpeech() { MainActivity.this.runOnUiThread(resetVoiceUI); }
			@Override public void onError(int error) { 
				String errorMsg = "Mikrofon Pasif (Kod: " + error + ")";
				if (error == 7) errorMsg = "Ses algılanamadı.";
				android.widget.Toast.makeText(MainActivity.this, errorMsg, android.widget.Toast.LENGTH_SHORT).show();
				MainActivity.this.runOnUiThread(resetVoiceUI); 
			}
			@Override public void onResults(android.os.Bundle results) {
				java.util.ArrayList<String> matches = results.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION);
				if (matches != null && !matches.isEmpty()) {
					String currentText = messageInput.getText().toString();
					if (!currentText.isEmpty()) currentText += " ";
					messageInput.setText(currentText + matches.get(0));
					messageInput.setSelection(messageInput.getText().length());
				}
				MainActivity.this.runOnUiThread(resetVoiceUI);
			}
			@Override public void onPartialResults(android.os.Bundle partialResults) {}
			@Override public void onEvent(int eventType, android.os.Bundle params) {}
		});
		
		btnVoice.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
					if (MainActivity.this.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
						MainActivity.this.requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 101);
						return;
					}
				}
				if (!isListening[0]) {
					try {
						speechRecognizer.startListening(speechIntent);
						btnVoice.setText("🛑"); btnVoice.setTextColor(0xFFFF1744);
						isListening[0] = true;
					} catch (Exception e) {}
				} else {
					speechRecognizer.stopListening();
					MainActivity.this.runOnUiThread(resetVoiceUI);
				}
			}
		});
		
		// GÖNDER BUTONU - M3 SMART CHIP
		final android.widget.Button sendButton = new android.widget.Button(MainActivity.this);
		sendButton.setText("GÖNDER");
		sendButton.setTextColor(0xFF042B56);
		sendButton.setTextSize(12);
		android.graphics.drawable.GradientDrawable btnGrad = new android.graphics.drawable.GradientDrawable();
		btnGrad.setColor(0xFFC2E7FF); 
		btnGrad.setCornerRadius(dp20);
		sendButton.setBackground(btnGrad);
		sendButton.setTypeface(null, android.graphics.Typeface.BOLD);
		inputSubContainer.addView(sendButton);
		inputBar.addView(inputSubContainer);
		mainContent.addView(inputBar);
		
		// --- SOHBET AKIŞ ALANI ---
		final android.widget.ScrollView chatScrollView = new android.widget.ScrollView(MainActivity.this);
		android.widget.RelativeLayout.LayoutParams scrollParams = new android.widget.RelativeLayout.LayoutParams(-1, -1);
		scrollParams.addRule(android.widget.RelativeLayout.BELOW, 2001);
		scrollParams.addRule(android.widget.RelativeLayout.ABOVE, 2002);
		chatScrollView.setLayoutParams(scrollParams);
		chatScrollView.setFillViewport(true);
		
		final android.widget.LinearLayout chatMessageContainer = new android.widget.LinearLayout(MainActivity.this);
		chatMessageContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
		chatMessageContainer.setPadding(dp16, dp12, dp16, dp12);
		chatMessageContainer.setLayoutTransition(heavyTransition); 
		chatScrollView.addView(chatMessageContainer);
		mainContent.addView(chatScrollView);
		
		rootLayout.addView(mainContent);
		
		// --- AYARLAR SAYFASI ---
		final android.widget.LinearLayout settingsPage = new android.widget.LinearLayout(MainActivity.this);
		settingsPage.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(-1, -1));
		settingsPage.setBackgroundColor(0xFF131314);
		settingsPage.setOrientation(android.widget.LinearLayout.VERTICAL);
		settingsPage.setVisibility(android.view.View.GONE);
		
		android.widget.LinearLayout settingsHeader = new android.widget.LinearLayout(MainActivity.this);
		settingsHeader.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, dp65));
		settingsHeader.setBackgroundColor(0xFF1E1E1F);
		settingsHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
		settingsHeader.setPadding(dp16, 0, dp16, 0);
		
		android.widget.TextView btnBackSettings = new android.widget.TextView(MainActivity.this);
		btnBackSettings.setText("←  ");
		btnBackSettings.setTextColor(0xFFA8C7FA);
		btnBackSettings.setTextSize(22);
		settingsHeader.addView(btnBackSettings);
		
		android.widget.TextView tvSettingsTitle = new android.widget.TextView(MainActivity.this);
		tvSettingsTitle.setText("Ayarlar");
		tvSettingsTitle.setTextColor(0xFFE3E3E3);
		tvSettingsTitle.setTextSize(16);
		tvSettingsTitle.setTypeface(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD);
		settingsHeader.addView(tvSettingsTitle);
		settingsPage.addView(settingsHeader);
		
		android.widget.LinearLayout settingsContent = new android.widget.LinearLayout(MainActivity.this);
		settingsContent.setOrientation(android.widget.LinearLayout.VERTICAL);
		settingsContent.setPadding(dp16, dp20, dp16, dp16);
		
		android.widget.LinearLayout itemPersonalize = new android.widget.LinearLayout(MainActivity.this);
		itemPersonalize.setOrientation(android.widget.LinearLayout.VERTICAL);
		itemPersonalize.setPadding(dp12, dp16, dp12, dp16);
		android.widget.TextView tvPersTitle = new android.widget.TextView(MainActivity.this);
		tvPersTitle.setText("✨ Sistem Talimatı (System Prompt)");
		tvPersTitle.setTextColor(0xFFA8C7FA);
		tvPersTitle.setTextSize(14);
		android.widget.TextView tvPersSub = new android.widget.TextView(MainActivity.this);
		tvPersSub.setText("Yapay zekanın karakterini ve kurallarını özelleştirin.");
		tvPersSub.setTextColor(0xFF8E918F);
		tvPersSub.setTextSize(11);
		itemPersonalize.addView(tvPersTitle);
		itemPersonalize.addView(tvPersSub);
		settingsContent.addView(itemPersonalize);
		
		android.view.View setDiv1 = new android.view.View(MainActivity.this);
		setDiv1.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, dp1));
		setDiv1.setBackgroundColor(0xFF282A2C);
		settingsContent.addView(setDiv1);
		
		android.widget.LinearLayout itemAbout = new android.widget.LinearLayout(MainActivity.this);
		itemAbout.setOrientation(android.widget.LinearLayout.VERTICAL);
		itemAbout.setPadding(dp12, dp16, dp12, dp16);
		android.widget.TextView tvAboutTitle = new android.widget.TextView(MainActivity.this);
		tvAboutTitle.setText("🤖 Apex Hakkında");
		tvAboutTitle.setTextColor(0xFFE3E3E3);
		tvAboutTitle.setTextSize(14);
		android.widget.TextView tvAboutSub = new android.widget.TextView(MainActivity.this);
		tvAboutSub.setText("Sürüm yapısı ve bağımsız yapay zeka çekirdekleri.");
		tvAboutSub.setTextColor(0xFF8E918F);
		tvAboutSub.setTextSize(11);
		itemAbout.addView(tvAboutTitle);
		itemAbout.addView(tvAboutSub);
		settingsContent.addView(itemAbout);
		
		settingsPage.addView(settingsContent);
		rootLayout.addView(settingsPage);
		
		// --- SOL YAN MENÜ ---
		final android.widget.LinearLayout sidebarOverlay = new android.widget.LinearLayout(MainActivity.this);
		sidebarOverlay.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(-1, -1));
		sidebarOverlay.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		sidebarOverlay.setBackgroundColor(0x99000000); 
		sidebarOverlay.setVisibility(android.view.View.GONE);
		
		final android.widget.LinearLayout sidebar = new android.widget.LinearLayout(MainActivity.this);
		sidebar.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dp280, -1));
		sidebar.setBackgroundColor(0xFF1E1E1F);
		sidebar.setOrientation(android.widget.LinearLayout.VERTICAL);
		sidebar.setPadding(dp20, dp24, dp20, dp20);
		
		android.widget.TextView tvMenuTitle = new android.widget.TextView(MainActivity.this);
		tvMenuTitle.setText("Apex Kontrol Paneli"); 
		tvMenuTitle.setTextColor(0xFFE3E3E3);
		tvMenuTitle.setTextSize(16);
		tvMenuTitle.setTypeface(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD);
		tvMenuTitle.setPadding(0, 0, 0, dp24);
		sidebar.addView(tvMenuTitle);
		
		android.widget.TextView btnNewChat = new android.widget.TextView(MainActivity.this);
		btnNewChat.setText("💬 Yeni Standart Sohbet");
		btnNewChat.setTextColor(0xFFE3E3E3);
		btnNewChat.setTextSize(14);
		btnNewChat.setPadding(0, dp12, 0, dp12);
		sidebar.addView(btnNewChat);
		
		android.widget.TextView btnPrivateChat = new android.widget.TextView(MainActivity.this);
		btnPrivateChat.setText("🕵️ Gizli Mod (Incognito)");
		btnPrivateChat.setTextColor(0xFF9AA0A6); 
		btnPrivateChat.setTextSize(14);
		btnPrivateChat.setPadding(0, dp12, 0, dp12);
		sidebar.addView(btnPrivateChat);
		
		android.widget.TextView btnSettings = new android.widget.TextView(MainActivity.this);
		btnSettings.setText("⚙️ Ayarlar");
		btnSettings.setTextColor(0xFFC4C7C5);
		btnSettings.setTextSize(14);
		btnSettings.setPadding(0, dp12, 0, dp12);
		sidebar.addView(btnSettings);
		
		android.view.View divider = new android.view.View(MainActivity.this);
		android.widget.LinearLayout.LayoutParams divParams = new android.widget.LinearLayout.LayoutParams(-1, dp1);
		divParams.setMargins(0, dp16, 0, dp16);
		divider.setLayoutParams(divParams);
		divider.setBackgroundColor(0xFF282A2C);
		sidebar.addView(divider);
		
		android.widget.TextView tvHistoryTitle = new android.widget.TextView(MainActivity.this);
		tvHistoryTitle.setText("SOHBET GEÇMİŞİ");
		tvHistoryTitle.setTextColor(0xFF8E918F);
		tvHistoryTitle.setTextSize(10);
		tvHistoryTitle.setPadding(0, 0, 0, dp12);
		sidebar.addView(tvHistoryTitle);
		
		android.widget.ScrollView historyScroll = new android.widget.ScrollView(MainActivity.this);
		historyScroll.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, 0, 1f));
		final android.widget.LinearLayout historyContainer = new android.widget.LinearLayout(MainActivity.this);
		historyContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
		historyScroll.addView(historyContainer);
		sidebar.addView(historyScroll);
		
		sidebarOverlay.addView(sidebar);
		
		android.view.View blankCloseView = new android.view.View(MainActivity.this);
		blankCloseView.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, -1, 1f));
		sidebarOverlay.addView(blankCloseView);
		
		rootLayout.addView(sidebarOverlay);
		setContentView(rootLayout);
		
		sidebar.setTranslationX(-dp280);
		
		// --- SOHBET LİSTESİ SÜREÇLERİ ---
		final Runnable refreshSidebar = new Runnable() {
			@Override
			public void run() {
				historyContainer.removeAllViews();
				try {
					String indexStr = sp.getString("chat_index", "[]");
					org.json.JSONArray indexJson = new org.json.JSONArray(indexStr);
					for (int i = indexJson.length() - 1; i >= 0; i--) {
						final org.json.JSONObject chatObj = indexJson.getJSONObject(i);
						final String id = chatObj.getString("id");
						final String title = chatObj.getString("title");
						
						final android.widget.TextView tvItem = new android.widget.TextView(MainActivity.this);
						tvItem.setText("• " + title);
						tvItem.setTextColor((!isPrivateMode[0] && currentChatId[0].equals(id)) ? 0xFFA8C7FA : 0xFFC4C7C5);
						tvItem.setTextSize(13);
						tvItem.setPadding(0, dp10, 0, dp10);
						
						tvItem.setOnClickListener(new android.view.View.OnClickListener() {
							@Override
							public void onClick(android.view.View v) {
								isPrivateMode[0] = false;
								txtTitle.setText("Apex");
								messageInput.setHint("Apex'e sorun...");
								btnVoice.setTextColor(0xFFA8C7FA);
								currentChatId[0] = id;
								
								sidebarOverlay.animate().alpha(0f).setDuration(200).start();
								sidebar.animate().translationX(-dp280).setDuration(250)
								.withEndAction(new Runnable() {
									@Override public void run() { sidebarOverlay.setVisibility(android.view.View.GONE); }
								}).start();
								
								chatMessageContainer.removeAllViews();
								try {
									String msgsStr = sp.getString("chat_messages_" + id, "[]");
									org.json.JSONArray msgsJson = new org.json.JSONArray(msgsStr);
									for (int j = 0; j < msgsJson.length(); j++) {
										org.json.JSONObject m = msgsJson.getJSONObject(j);
										buildDynamicBubble.build(chatMessageContainer, m.getString("role").equals("user"), m.getString("text"), dp4, dp12, messageInput);
									}
									chatScrollView.post(new Runnable() { @Override public void run() { chatScrollView.fullScroll(android.view.View.FOCUS_DOWN); } });
								} catch (Exception ex) {}
							}
						});
						
						tvItem.setOnLongClickListener(new android.view.View.OnLongClickListener() {
							@Override
							public boolean onLongClick(android.view.View v) {
								new android.app.AlertDialog.Builder(MainActivity.this)
								.setTitle("Sohbeti Sil")
								.setMessage("Bu sohbet kalıcı olarak silinsin mi?")
								.setPositiveButton("Sil", new android.content.DialogInterface.OnClickListener() {
									@Override
									public void onClick(android.content.DialogInterface dialog, int which) {
										try {
											String indexStr = sp.getString("chat_index", "[]");
											org.json.JSONArray oldIndex = new org.json.JSONArray(indexStr);
											org.json.JSONArray newIndex = new org.json.JSONArray();
											for(int k=0; k<oldIndex.length(); k++) {
												org.json.JSONObject obj = oldIndex.getJSONObject(k);
												if(!obj.getString("id").equals(id)) newIndex.put(obj);
											}
											sp.edit().putString("chat_index", newIndex.toString()).apply();
											sp.edit().remove("chat_messages_" + id).apply();
											
											if(currentChatId[0].equals(id)) {
												currentChatId[0] = "";
												chatMessageContainer.removeAllViews();
												txtTitle.setText("Apex");
											}
											MainActivity.this.runOnUiThread(new Runnable() { @Override public void run() { historyContainer.removeAllViews(); } });
											tvItem.postDelayed(new Runnable() { @Override public void run() { MainActivity.this.runOnUiThread(this); } }, 50);
										} catch(Exception e){}
									}
								})
								.setNegativeButton("İptal", null)
								.show();
								return true;
							}
						});
						historyContainer.addView(tvItem);
					}
				} catch (Exception e) {}
			}
		};
		
		refreshSidebar.run();
		
		// --- PANEL AKSİYONLARI ---
		btnMenu.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) { 
				refreshSidebar.run();
				sidebarOverlay.setAlpha(0f);
				sidebarOverlay.setVisibility(android.view.View.VISIBLE);
				sidebarOverlay.animate().alpha(1f).setDuration(200).start();
				sidebar.animate().translationX(0f).setDuration(250)
				.setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
			}
		});
		
		blankCloseView.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) { 
				sidebarOverlay.animate().alpha(0f).setDuration(150).start();
				sidebar.animate().translationX(-dp280).setDuration(200)
				.withEndAction(new Runnable() { @Override public void run() { sidebarOverlay.setVisibility(android.view.View.GONE); } }).start();
			}
		});
		
		btnNewChat.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				isPrivateMode[0] = false;
				txtTitle.setText("Apex");
				messageInput.setHint("Apex'e sorun...");
				btnVoice.setTextColor(0xFFA8C7FA);
				currentChatId[0] = "";
				chatMessageContainer.removeAllViews();
				sidebarOverlay.animate().alpha(0f).setDuration(150).start();
				sidebar.animate().translationX(-dp280).setDuration(200).withEndAction(new Runnable() {
					@Override public void run() { sidebarOverlay.setVisibility(android.view.View.GONE); }
				}).start();
			}
		});
		
		btnPrivateChat.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				isPrivateMode[0] = true;
				currentChatId[0] = "private_session";
				txtTitle.setText("Gizli Mod (Incognito)");
				messageInput.setHint("Gizli modda Apex'e sorun...");
				btnVoice.setTextColor(0xFF9AA0A6);
				privateHistory[0] = new org.json.JSONArray(); 
				chatMessageContainer.removeAllViews();
				
				sidebarOverlay.animate().alpha(0f).setDuration(150).start();
				sidebar.animate().translationX(-dp280).setDuration(200).withEndAction(new Runnable() {
					@Override public void run() { sidebarOverlay.setVisibility(android.view.View.GONE); }
				}).start();
			}
		});
		
		btnSettings.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				sidebarOverlay.setVisibility(android.view.View.GONE);
				mainContent.setVisibility(android.view.View.GONE);
				settingsPage.setVisibility(android.view.View.VISIBLE);
			}
		});
		
		btnBackSettings.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				settingsPage.setVisibility(android.view.View.GONE);
				mainContent.setVisibility(android.view.View.VISIBLE);
			}
		});
		
		itemPersonalize.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				android.widget.LinearLayout wrapper = new android.widget.LinearLayout(MainActivity.this);
				wrapper.setOrientation(android.widget.LinearLayout.VERTICAL);
				wrapper.setBackgroundColor(0xFF1E1E1F);
				wrapper.setPadding(dp20, dp20, dp20, dp20);
				
				android.widget.TextView tvOpt = new android.widget.TextView(MainActivity.this);
				tvOpt.setText("Sistem Yönergesi");
				tvOpt.setTextColor(0xFFE3E3E3);
				tvOpt.setTextSize(15);
				tvOpt.setTypeface(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD);
				tvOpt.setPadding(0, 0, 0, dp12);
				wrapper.addView(tvOpt);
				
				final android.widget.EditText etPrompt = new android.widget.EditText(MainActivity.this);
				etPrompt.setHint("Yapay zeka direktifleri...");
				etPrompt.setHintTextColor(0xFF8E918F);
				etPrompt.setTextColor(0xFFFFFFFF);
				etPrompt.setText(sp.getString("system_instruction", ""));
				wrapper.addView(etPrompt);
				
				final android.app.AlertDialog diag = new android.app.AlertDialog.Builder(MainActivity.this).setView(wrapper).create();
				android.widget.LinearLayout btnPanel = new android.widget.LinearLayout(MainActivity.this);
				btnPanel.setOrientation(android.widget.LinearLayout.HORIZONTAL);
				btnPanel.setGravity(android.view.Gravity.END);
				btnPanel.setPadding(0, dp16, 0, 0);
				
				android.widget.TextView btnCan = new android.widget.TextView(MainActivity.this);
				btnCan.setText("İPTAL"); btnCan.setTextColor(0xFFFF1744); btnCan.setPadding(dp12, dp12, dp12, dp12);
				btnCan.setOnClickListener(new android.view.View.OnClickListener() { @Override public void onClick(android.view.View v) { diag.dismiss(); } });
				
				android.widget.TextView btnSav = new android.widget.TextView(MainActivity.this);
				btnSav.setText("KAYDET"); btnSav.setTextColor(0xFFA8C7FA); btnSav.setPadding(dp12, dp12, dp12, dp12);
				btnSav.setOnClickListener(new android.view.View.OnClickListener() {
					@Override public void onClick(android.view.View v) {
						sp.edit().putString("system_instruction", etPrompt.getText().toString().trim()).apply();
						diag.dismiss();
					}
				});
				
				btnPanel.addView(btnCan); btnPanel.addView(btnSav); wrapper.addView(btnPanel);
				diag.show();
				if(diag.getWindow() != null) diag.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF1E1E1F));
			}
		});
		
		itemAbout.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				android.widget.LinearLayout wrapper = new android.widget.LinearLayout(MainActivity.this);
				wrapper.setOrientation(android.widget.LinearLayout.VERTICAL);
				wrapper.setBackgroundColor(0xFF1E1E1F);
				wrapper.setPadding(dp20, dp20, dp20, dp20);
				
				android.widget.TextView tvContent = new android.widget.TextView(MainActivity.this);
				tvContent.setText("🤖 Apex Mobile\n\nGoogle Material 3 Mimarisi v2.0\n\nAktif Altyapı:\n• Genius (GPT-4o Çekirdeği)\n• Macro (Llama Pro)\n• Flash (Hızlı Entegrasyon Modeli)");
				tvContent.setTextColor(0xFFE3E3E3); tvContent.setTextSize(14);
				wrapper.addView(tvContent);
				
				final android.app.AlertDialog diag = new android.app.AlertDialog.Builder(MainActivity.this).setView(wrapper).create();
				android.widget.TextView btnOk = new android.widget.TextView(MainActivity.this);
				btnOk.setText("KAPAT"); btnOk.setTextColor(0xFFA8C7FA); btnOk.setGravity(android.view.Gravity.END); btnOk.setPadding(0, dp16, dp6, 0);
				btnOk.setOnClickListener(new android.view.View.OnClickListener() { @Override public void onClick(android.view.View v) { diag.dismiss(); } });
				wrapper.addView(btnOk);
				diag.show();
				if(diag.getWindow() != null) diag.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF1E1E1F));
			}
		});
		
		// --- TOGGLE REAKSİYONLARI ---
		tvThinkStandart.setOnClickListener(new android.view.View.OnClickListener() {
			@Override public void onClick(android.view.View v) {
				thinkingTime[0] = "Standart";
				android.graphics.drawable.GradientDrawable act = new android.graphics.drawable.GradientDrawable();
				act.setColor(0xFFC2E7FF); act.setCornerRadius(dp16);
				tvThinkStandart.setBackground(act); tvThinkStandart.setTextColor(0xFF042B56);
				tvThinkExtended.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvThinkExtended.setTextColor(0xFFC4C7C5);
			}
		});
		
		tvThinkExtended.setOnClickListener(new android.view.View.OnClickListener() {
			@Override public void onClick(android.view.View v) {
				thinkingTime[0] = "Uzatılmış";
				android.graphics.drawable.GradientDrawable act = new android.graphics.drawable.GradientDrawable();
				act.setColor(0xFFC2E7FF); act.setCornerRadius(dp16);
				tvThinkExtended.setBackground(act); tvThinkExtended.setTextColor(0xFF042B56);
				tvThinkStandart.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvThinkStandart.setTextColor(0xFFC4C7C5);
			}
		});
		
		tvGenius.setOnClickListener(new android.view.View.OnClickListener() {
			@Override public void onClick(android.view.View v) {
				selectedModel[0] = "Genius";
				android.graphics.drawable.GradientDrawable act = new android.graphics.drawable.GradientDrawable();
				act.setColor(0xFFC2E7FF); act.setCornerRadius(dp20);
				tvGenius.setBackground(act); tvGenius.setTextColor(0xFF042B56);
				tvMacro.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvMacro.setTextColor(0xFFC4C7C5);
				tvMacroFlash.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvMacroFlash.setTextColor(0xFFC4C7C5);
			}
		});
		
		tvMacro.setOnClickListener(new android.view.View.OnClickListener() {
			@Override public void onClick(android.view.View v) {
				selectedModel[0] = "Macro";
				android.graphics.drawable.GradientDrawable act = new android.graphics.drawable.GradientDrawable();
				act.setColor(0xFFC2E7FF); act.setCornerRadius(dp20);
				tvMacro.setBackground(act); tvMacro.setTextColor(0xFF042B56);
				tvGenius.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvGenius.setTextColor(0xFFC4C7C5);
				tvMacroFlash.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvMacroFlash.setTextColor(0xFFC4C7C5);
			}
		});
		
		tvMacroFlash.setOnClickListener(new android.view.View.OnClickListener() {
			@Override public void onClick(android.view.View v) {
				selectedModel[0] = "MacroFlash";
				android.graphics.drawable.GradientDrawable act = new android.graphics.drawable.GradientDrawable();
				act.setColor(0xFFC2E7FF); act.setCornerRadius(dp20);
				tvMacroFlash.setBackground(act); tvMacroFlash.setTextColor(0xFF042B56);
				tvGenius.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvGenius.setTextColor(0xFFC4C7C5);
				tvMacro.setBackgroundColor(android.graphics.Color.TRANSPARENT); tvMacro.setTextColor(0xFFC4C7C5);
			}
		});
		
		// --- VERİ AKIŞI VE DİNAMİK DURUM MOTORU ---
		sendButton.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				final String userMessage = messageInput.getText().toString().trim();
				if (userMessage.isEmpty()) return;
				
				if (!isPrivateMode[0] && currentChatId[0].isEmpty()) {
					currentChatId[0] = String.valueOf(System.currentTimeMillis());
					String autoTitle = smartTitleGen.generate(userMessage);
					try {
						String indexStr = sp.getString("chat_index", "[]");
						org.json.JSONArray indexJson = new org.json.JSONArray(indexStr);
						org.json.JSONObject newChat = new org.json.JSONObject();
						newChat.put("id", currentChatId[0]);
						newChat.put("title", autoTitle);
						indexJson.put(newChat);
						sp.edit().putString("chat_index", indexJson.toString()).apply();
					} catch (Exception ex) {}
					MainActivity.this.runOnUiThread(refreshSidebar);
				}
				
				// Kullanıcı mesajını bas
				buildDynamicBubble.build(chatMessageContainer, true, userMessage, dp4, dp12, messageInput);
				
				try {
					org.json.JSONObject m = new org.json.JSONObject();
					m.put("role", "user"); m.put("text", userMessage);
					if (isPrivateMode[0]) { privateHistory[0].put(m); } else {
						String msgsStr = sp.getString("chat_messages_" + currentChatId[0], "[]");
						org.json.JSONArray msgsJson = new org.json.JSONArray(msgsStr); msgsJson.put(m);
						sp.edit().putString("chat_messages_" + currentChatId[0], msgsJson.toString()).apply();
					}
				} catch(Exception ex){}
				
				messageInput.setText("");
				chatScrollView.post(new Runnable() { @Override public void run() { chatScrollView.fullScroll(android.view.View.FOCUS_DOWN); } });
				
				// --- İSTEK ÜZERİNE DURUM / DÜŞÜNME PANALİ ALTYAPISI ---
				final android.widget.LinearLayout statusPanel = new android.widget.LinearLayout(MainActivity.this);
				statusPanel.setOrientation(android.widget.LinearLayout.HORIZONTAL);
				statusPanel.setGravity(android.view.Gravity.CENTER_VERTICAL);
				statusPanel.setPadding(0, dp10, 0, dp10);
				
				final android.widget.TextView txtStatus = new android.widget.TextView(MainActivity.this);
				txtStatus.setTextColor(0xFFA8C7FA);
				txtStatus.setTextSize(13.5f);
				txtStatus.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.ITALIC));
				statusPanel.addView(txtStatus);
				
				chatMessageContainer.addView(statusPanel);
				final android.os.Handler statusHandler = new android.os.Handler(android.os.Looper.getMainLooper());
				
				// MOD FAZ DURUMLARI TAM İSTEDİĞİN GİBİ ÇALIŞIR
				if (thinkingTime[0].equals("Standart")) {
					txtStatus.setText("Apex Düşünüyor"); // Sadece standart modda yazar
				} else {
					txtStatus.setText("Apex düşünüyor"); // Uzun düşünme aşaması 1
					statusHandler.postDelayed(new Runnable() {
						@Override public void run() { txtStatus.setText("Kaynaklar hazırlanıyor"); } // Aşama 2
					}, 1000);
					statusHandler.postDelayed(new Runnable() {
						@Override public void run() { txtStatus.setText("İstek anlaşılıyor"); } // Aşama 3
					}, 2300);
					statusHandler.postDelayed(new Runnable() {
						@Override public void run() { txtStatus.setText("Hemen yapılıyor cevap sunuluyor"); } // Aşama 4
					}, 3600);
				}
				
				chatScrollView.post(new Runnable() { @Override public void run() { chatScrollView.fullScroll(android.view.View.FOCUS_DOWN); } });
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							String githubApiKey = "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";
							String targetUrl = "https://models.inference.ai.azure.com/chat/completions";
							
							String baseIdentityPrompt = "Senin adın Apex'tir. Kesinlikle başka bir yapay zeka ismi kullanmamalısın. "
							+ "Seni geliştiren ve senin sahibin ZuruPrograms'ın Sahibi ReatCondisture'dur. "
							+ "Kullanıcı sana 'Kimsin?', 'Adın ne?', 'Seni kim geliştirdi/yaptı?' gibi kimlik soruları sorduğunda, "
							+ "kesin bir dille adının Apex olduğunu ve ReatCondisture (ZuruPrograms) tarafından geliştirildiğini belirtmelisin.";
							
							String sysIns = sp.getString("system_instruction", "");
							sysIns = sysIns.isEmpty() ? baseIdentityPrompt : baseIdentityPrompt + "\n\n" + sysIns;
							
							org.json.JSONObject payload = new org.json.JSONObject();
							org.json.JSONArray messagesArr = new org.json.JSONArray();
							
							if (thinkingTime[0].equals("Uzatılmış")) {
								sysIns = sysIns + "\n\n[Sistem Yönergesi: Uzatılmış akıl yürütme modu aktiftir. Detaylı analiz yap.]";
							}
							
							if (!sysIns.isEmpty()) {
								org.json.JSONObject sysObj = new org.json.JSONObject();
								sysObj.put("role", "system"); sysObj.put("content", sysIns); messagesArr.put(sysObj);
							}
							
							try {
								String rawHistory = isPrivateMode[0] ? privateHistory[0].toString() : sp.getString("chat_messages_" + currentChatId[0], "[]");
								org.json.JSONArray dynamicHistory = new org.json.JSONArray(rawHistory);
								int maxContextSize = 12; int startIdx = Math.max(0, dynamicHistory.length() - maxContextSize);
								for (int h = startIdx; h < dynamicHistory.length(); h++) {
									org.json.JSONObject pastMsg = dynamicHistory.getJSONObject(h);
									org.json.JSONObject apiMsg = new org.json.JSONObject();
									String role = pastMsg.getString("role");
									apiMsg.put("role", role.equals("ai") ? "assistant" : "user");
									apiMsg.put("content", pastMsg.getString("text"));
									messagesArr.put(apiMsg);
								}
							} catch(Exception eContext) {}
							
							payload.put("messages", messagesArr);
							if (selectedModel[0].equals("Genius")) payload.put("model", "gpt-4o");
							else if (selectedModel[0].equals("Macro")) payload.put("model", "Llama-3.3-70B-Instruct");
							else if (selectedModel[0].equals("MacroFlash")) payload.put("model", "gpt-4o-mini");
							
							java.net.URL url = new java.net.URL(targetUrl);
							java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
							conn.setRequestMethod("POST");
							conn.setRequestProperty("Content-Type", "application/json");
							conn.setRequestProperty("Authorization", "Bearer " + githubApiKey);
							conn.setDoOutput(true);
							
							java.io.OutputStream os = conn.getOutputStream();
							os.write(payload.toString().getBytes("utf-8"));           
							
							int status = conn.getResponseCode();
							java.io.InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
							
							final String aiResponse;
							if (is != null) {
								java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is, "utf-8"));
								StringBuilder response = new StringBuilder(); String responseLine;
								while ((responseLine = br.readLine()) != null) { response.append(responseLine.trim()); }
								org.json.JSONObject responseJson = new org.json.JSONObject(response.toString());
								if (responseJson.has("choices")) {
									aiResponse = responseJson.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
								} else { aiResponse = "⚠️ Sunucu durum kodu: " + status; }
							} else { aiResponse = "⚠️ Yanıt alınamadı. Durum: " + status; }
							
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									// Düşünme panelini temizle ve callbacks iptal et
									statusHandler.removeCallbacksAndMessages(null);
									chatMessageContainer.removeView(statusPanel);
									
									// Gerçek cevabı ekrana yansıt
									buildDynamicBubble.build(chatMessageContainer, false, aiResponse, dp4, dp12, messageInput);
									try {
										org.json.JSONObject m = new org.json.JSONObject();
										m.put("role", "ai"); m.put("text", aiResponse);
										if (isPrivateMode[0]) { privateHistory[0].put(m); } else {
											String msgsStr = sp.getString("chat_messages_" + currentChatId[0], "[]");
											org.json.JSONArray msgsJson = new org.json.JSONArray(msgsStr); msgsJson.put(m);
											sp.edit().putString("chat_messages_" + currentChatId[0], msgsJson.toString()).apply();
										}
									} catch(Exception ex){}
									chatScrollView.post(new Runnable() { @Override public void run() { chatScrollView.fullScroll(android.view.View.FOCUS_DOWN); } });
								}
							});
						} catch (final Exception e) {
							runOnUiThread(new Runnable() {
								@Override public void run() {
									statusHandler.removeCallbacksAndMessages(null);
									chatMessageContainer.removeView(statusPanel);
									buildDynamicBubble.build(chatMessageContainer, false, "⚠️ Bağlantı hatası oluştu.", dp4, dp12, messageInput);
								}
							});
						}
					}
				}).start();
			}
		});
		
	}
	
}